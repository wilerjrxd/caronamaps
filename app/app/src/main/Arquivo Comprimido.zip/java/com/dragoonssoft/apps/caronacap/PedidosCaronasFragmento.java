package com.dragoonssoft.apps.caronacap;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseListAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;

import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;


/**
 * A simple {@link Fragment} subclass.
 */
public class PedidosCaronasFragmento extends Fragment {


    private FirebaseAuth mAuth;
    private DatabaseReference usuariosRef;
    private FirebaseListAdapter<Notification> firebasePedidosListAdapter;
   // private String usuarioImgUrl, usuarioId, usuarioNome;
    private ListView pedidosList;
    private String notificationType;
    private String notificationId;
    private int numVagas;
    private String numVagasTxt;
    private long horario;
    private DatabaseReference conversasRef;
    private ProgressDialog mCheckingAuthProgress;
    private int contador = 0;
    private TextView nenhumPedidoTxt;
    private TextView nenhumResultadoEncontrado;
    private int numPedidos = 0;
    private GetTimeAgo getTimeAgo = new GetTimeAgo();
    private ConnectivityManager connMgr;
    private NetworkInfo networkInfo;
    private boolean isDone = false;
    private DatabaseReference notificationsOffRef;
    private AlertDialog.Builder alert_builder, alert_builder2;
    private AlertDialog alert, alert2;
    private DatabaseReference caronaRef;
    private int contadorDeNotificacoes = 0;
    private ArrayList pedidosArrayList;
    private String nomeUsuarioQuePediu, imgUsuarioQuePediu, telefoneUsuarioQuePediu;
    private CountDownTimer carregarPedidosTimer;
    private int counter = 0;
    private boolean pedidosJaCarregados = false;
    private ValueEventListener pedidosListener;
    private ChildEventListener pedidosChildListener;
    static boolean pedidoAdded = false;
    private String vagasDisponiveis;
    private TimerTask task;
    final private static long INTERVAL=1000;
    final private static long TIMEOUT=10000;
    private long elapsed = 0;
    private Timer timer;
    private CountDownTimer abrirConversaTimer;
    private boolean dadosDoOutroUsuarioJaCarregados = false;
    private String nomecaroneiro1, nomecaroneiro2, nomecaroneiro3, nomecaroneiro4;

    public PedidosCaronasFragmento() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.pedidos_caronas_fragmento, container, false);

        setHasOptionsMenu(true);

        pedidosList = (ListView) view.findViewById(R.id.pedidosList);
        nenhumResultadoEncontrado = (TextView) view.findViewById(R.id.nenhum_resultado);
        nenhumResultadoEncontrado.setVisibility(View.VISIBLE);

        mAuth = FirebaseAuth.getInstance();
        notificationsOffRef = FirebaseDatabase.getInstance().getReference().child("notifications_off");
        usuariosRef = FirebaseDatabase.getInstance().getReference().child("usuarios");
        caronaRef = FirebaseDatabase.getInstance().getReference().child("caronas");

        mCheckingAuthProgress = new ProgressDialog(getActivity());
        mCheckingAuthProgress.setMessage("Aceitando o pedido de carona...");
        mCheckingAuthProgress.setCanceledOnTouchOutside(false);
        mCheckingAuthProgress.setCancelable(false);

        setupImageLoader();
        ImageLoader imageLoader = ImageLoader.getInstance();
        int defaultImage = getActivity().getApplicationContext().getResources().getIdentifier("@drawable/ic_launcher",null,getActivity().getApplicationContext().getPackageName());
        DisplayImageOptions options = new DisplayImageOptions.Builder().cacheInMemory(true)
                .cacheOnDisk(true).resetViewBeforeLoading(true)
                .showImageForEmptyUri(defaultImage)
                .showImageOnFail(defaultImage)
                .showImageOnLoading(defaultImage).build();

        firebasePedidosListAdapter = new FirebaseListAdapter<Notification>(getActivity(), Notification.class, R.layout.pedido_item_view, notificationsOffRef.child(mAuth.getCurrentUser().getUid())) {
            @Override
            protected void populateView(View view, Notification notificationInfo, int position) {
                if(notificationInfo.getType().equals("pedido")) {
                    TextView textView = (TextView) view.findViewById(R.id.textPedidoItemList);
                    TextView horarioView = (TextView) view.findViewById(R.id.horarioPedidoItemList);
                    ImageButton aceitarPedidoView = (ImageButton) view.findViewById(R.id.aceitarPedidoItemList);
                    ImageView imgView = (ImageView) view.findViewById(R.id.profileImagePedidoItemList);

                    final String usuarioId = notificationInfo.getFrom();//notificationId = getRef(position).getKey();
                    final String usuarioNome = notificationInfo.getNome();
                    final String usuarioImg = notificationInfo.getImg();
                    final String usuarioTelefone = notificationInfo.getTelefone();

                    if (usuarioId != null || !usuarioId.equals("")) {
                        nenhumResultadoEncontrado.setVisibility(View.GONE);
                    } else {
                        nenhumResultadoEncontrado.setVisibility(View.VISIBLE);
                    }
                    textView.setText(notificationInfo.getNome() + " pediu carona para você.");
                    horario = notificationInfo.getHorario();
                    horarioView.setText(getTimeAgo.getTimeAgo(horario, getActivity().getApplicationContext()));
                    imageLoader.displayImage(notificationInfo.getImg(), imgView, options);
                    aceitarPedidoView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ConnectivityManager connMgr = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
                            NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
                            if (networkInfo != null && networkInfo.isConnected()) {
                                aceitarPedidoCarona(usuarioId, usuarioNome , usuarioImg, usuarioTelefone, getRef(position).getKey());
                            } else {
                                Toast.makeText(getActivity().getApplicationContext(), "Você precisa estar conectado à Internet para fazer isso.", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
                    imgView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent abrirConversa = new Intent(getActivity().getApplicationContext(), Conversa.class);
                            abrirConversa.putExtra("idusuario_chat", usuarioId);
                            abrirConversa.putExtra("nomeusuario_chat", usuarioNome);
                            abrirConversa.putExtra("imgusuario_chat", usuarioImg);
                            abrirConversa.putExtra("telefoneusuario_chat", usuarioTelefone);
                            startActivity(abrirConversa);
                        }
                    });
                }
            }
                        // }

        };
        pedidosList.setAdapter(firebasePedidosListAdapter);
        /*pedidosArrayList = new ArrayList<>();
        adapter = new PedidosListAdapter(getActivity().getApplicationContext(), R.layout.pedido_item_view, pedidosArrayList);
        pedidosList.setAdapter(adapter);*/

        //carregarPedidos();

        notificationsOffRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    if(ds.exists()) {
                        if (ds.hasChild("type")) {
                            nenhumResultadoEncontrado.setVisibility(View.INVISIBLE);
                        } else {
                            nenhumResultadoEncontrado.setVisibility(View.VISIBLE);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        
        return view;
    }


    private void setupImageLoader(){
        DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder()
                .cacheOnDisc(true).cacheInMemory(true)
                .imageScaleType(ImageScaleType.EXACTLY)
                .displayer(new FadeInBitmapDisplayer(300)).build();

        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
                getActivity().getApplicationContext())
                .defaultDisplayImageOptions(defaultOptions)
                .memoryCache(new WeakMemoryCache())
                .discCacheSize(100*1024*1024).build();

        ImageLoader.getInstance().init(config);
    }

    @Override
    public void onStart() {
        super.onStart();

    }

    @Override
    public void onResume() {
        super.onResume();

        //notificationsOffRef.goOnline();
        //usuariosRef.goOnline();
        //caronaRef.goOnline();


    }


    @Override
    public void onPause() {

        super.onPause();

        if(mCheckingAuthProgress != null){
            mCheckingAuthProgress.dismiss();
        }

        //notificationsOffRef.goOffline();
        //usuariosRef.goOffline();
        //caronaRef.goOffline();

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        //pedidosArrayList.clear();
        if(mCheckingAuthProgress != null)
            mCheckingAuthProgress.dismiss();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater){

        inflater.inflate(R.menu.menu_home_tabbed, menu);
        MenuItem searchItem = menu.findItem(R.id.procurarItem);
        searchItem.setVisible(false);
        /*MenuItem searchItem = menu.findItem(R.id.procurarItem);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if(newText == null || newText.length() < 3){
                    caronasList.setAdapter(firebaseListAdapter);
                    return true;
                }else{
                    jaPesquisado = false;
                    searchOnFirebaseListViewAdapter(newText.toLowerCase());
                    Toast.makeText(getActivity().getApplicationContext(), "Executando pesquisa...", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });*/

        super.onCreateOptionsMenu(menu, inflater);

    }

    private void aceitarPedidoCarona(String usuarioId, String usuarioNome, String usuarioImgUrl, String usuarioTelefone, String notificationId) {
        task=new TimerTask(){
            @Override
            public void run() {
                elapsed+=INTERVAL;
                if(elapsed>=TIMEOUT){
                    this.cancel();
                    elapsed = 0;
                    mCheckingAuthProgress.hide();
                    Toast.makeText(getActivity().getApplicationContext(), "Pode ser que sua conexão com a Internet tenha expirado. Tente novamente mais tarde.", Toast.LENGTH_SHORT).show();
                    return;
                }else{
                    checkVagasCarona(usuarioId, usuarioNome, usuarioImgUrl, usuarioTelefone, notificationId);
                }
            }
        };
        timer = new Timer();
        timer.scheduleAtFixedRate(task, INTERVAL, TIMEOUT);
    }

    private void checkVagasCarona(String usuarioId, String usuarioNome, String usuarioImgUrl, String usuarioTelefone, String notificationId){
        caronaRef.child(ListaCaronasFragmento.idParaVerCarona).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    if(dataSnapshot.hasChild("vagas")){
                        vagasDisponiveis = dataSnapshot.child("vagas").getValue().toString();
                        nomecaroneiro1 = dataSnapshot.child("nomecaroneiro1").getValue().toString();
                        nomecaroneiro2 = dataSnapshot.child("nomecaroneiro2").getValue().toString();
                        nomecaroneiro3 = dataSnapshot.child("nomecaroneiro3").getValue().toString();
                        nomecaroneiro4 = dataSnapshot.child("nomecaroneiro4").getValue().toString();
                        if(vagasDisponiveis != null && nomecaroneiro1 != null && nomecaroneiro2 != null && nomecaroneiro3 != null && nomecaroneiro4 != null){
                            task.cancel();
                            elapsed = 0;
                            if(vagasDisponiveis.contains("0")){
                                numVagas = 0;
                            }else if(vagasDisponiveis.contains("1")){
                                numVagas = 1;
                            }else if(vagasDisponiveis.contains("2")){
                                numVagas = 2;
                            }else if(vagasDisponiveis.contains("3")){
                                numVagas = 3;
                            }else if(vagasDisponiveis.contains("4")){
                                numVagas = 4;
                            }

                            if(numVagas == 0){
                                alert_builder = new AlertDialog.Builder(getActivity());
                                alert_builder.setMessage("Sua carona já está cheia. Remova alguém para aceitar o pedido de " + usuarioNome + ".")
                                        .setCancelable(true).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        alert.hide();
                                    }
                                });
                                alert = alert_builder.create();
                                alert.show();

                            }else{

                                mCheckingAuthProgress.show();

                                numVagas--;
                                if(numVagas <= 1){
                                    numVagasTxt = String.valueOf(numVagas) + " vaga";
                                }else{
                                    numVagasTxt = String.valueOf(numVagas) + " vagas";
                                }

                                Map novoCaroneiroMap = new HashMap();

                                //criar um alerta para fazer o motorista enviar uma msg para o caroneiro para que combinem o lugar certo de se encontrarem
                                if("ASSENTO VAZIO".equals(nomecaroneiro1)){
                                    novoCaroneiroMap.put("idcaroneiro1", usuarioId);
                                    novoCaroneiroMap.put("nomecaroneiro1", usuarioNome);
                                    novoCaroneiroMap.put("imgcaroneiro1", usuarioImgUrl);
                                    novoCaroneiroMap.put("vagas", numVagasTxt);
                                    caronaRef.child(ListaCaronasFragmento.idParaVerCarona).updateChildren(novoCaroneiroMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful()){

                                                HashMap<String, String> notificationInfo = new HashMap<>();
                                                notificationInfo.put("from", mAuth.getCurrentUser().getUid());
                                                notificationInfo.put("type", "pedido_aceito");
                                                usuariosRef.child(usuarioId).child("status").setValue("caroneiro_" + mAuth.getCurrentUser().getUid());
                                                //usuariosRef.child(mAuth.getCurrentUser().getUid()).child("pedidos").child(usuarioId).removeValue();
                                                notificationsOffRef.child(mAuth.getCurrentUser().getUid()).child(notificationId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if(task.isSuccessful()){
                                                            removePedidosDoCaroneiroEmOutrasCaronas(usuarioId);
                                                            FirebaseDatabase.getInstance().getReference().child("notifications").child(usuarioId).push().setValue(notificationInfo);
                                                            Toast.makeText(getActivity().getApplicationContext(), usuarioNome + " entrou na sua carona", Toast.LENGTH_SHORT).show();
                                                            criarAlertaParaEnvioDeMsgAoCaroneiro(usuarioId, usuarioNome, usuarioImgUrl, usuarioTelefone);
                                                            mCheckingAuthProgress.hide();
                                                        }
                                                    }
                                                });
                                            }else{
                                                Toast.makeText(getContext(), "Algo deu errado. Tente novamente.", Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                                }else if("ASSENTO VAZIO".equals(nomecaroneiro2)){
                                    novoCaroneiroMap.put("idcaroneiro2", usuarioId);
                                    novoCaroneiroMap.put("nomecaroneiro2", usuarioNome);
                                    novoCaroneiroMap.put("imgcaroneiro2", usuarioImgUrl);
                                    novoCaroneiroMap.put("vagas", numVagasTxt);
                                    caronaRef.child(ListaCaronasFragmento.idParaVerCarona).updateChildren(novoCaroneiroMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful()){
                                                HashMap<String, String> notificationInfo = new HashMap<>();
                                                notificationInfo.put("from", mAuth.getCurrentUser().getUid());
                                                notificationInfo.put("type", "pedido_aceito");

                                                usuariosRef.child(usuarioId).child("status").setValue("caroneiro_" + mAuth.getCurrentUser().getUid());
                                                //usuariosRef.child(mAuth.getCurrentUser().getUid()).child("pedidos").child(usuarioId).removeValue();
                                                notificationsOffRef.child(mAuth.getCurrentUser().getUid()).child(notificationId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if(task.isSuccessful()){
                                                            removePedidosDoCaroneiroEmOutrasCaronas(usuarioId);
                                                            FirebaseDatabase.getInstance().getReference().child("notifications").child(usuarioId).push().setValue(notificationInfo);
                                                            Toast.makeText(getActivity().getApplicationContext(), usuarioNome + " entrou na sua carona", Toast.LENGTH_SHORT).show();
                                                            criarAlertaParaEnvioDeMsgAoCaroneiro(usuarioId, usuarioNome, usuarioImgUrl, usuarioTelefone);
                                                            mCheckingAuthProgress.hide();
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    });
                                }else if("ASSENTO VAZIO".equals(nomecaroneiro3)) {
                                    novoCaroneiroMap.put("idcaroneiro3", usuarioId);
                                    novoCaroneiroMap.put("nomecaroneiro3", usuarioNome);
                                    novoCaroneiroMap.put("imgcaroneiro3", usuarioImgUrl);
                                    novoCaroneiroMap.put("vagas", numVagasTxt);
                                    caronaRef.child(ListaCaronasFragmento.idParaVerCarona).updateChildren(novoCaroneiroMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful()){

                                                HashMap<String, String> notificationInfo = new HashMap<>();
                                                notificationInfo.put("from", mAuth.getCurrentUser().getUid());
                                                notificationInfo.put("type", "pedido_aceito");

                                                usuariosRef.child(usuarioId).child("status").setValue("caroneiro_" + mAuth.getCurrentUser().getUid());
                                                //usuariosRef.child(mAuth.getCurrentUser().getUid()).child("pedidos").child(usuarioId).removeValue();
                                                notificationsOffRef.child(mAuth.getCurrentUser().getUid()).child(notificationId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if(task.isSuccessful()){
                                                            removePedidosDoCaroneiroEmOutrasCaronas(usuarioId);
                                                            FirebaseDatabase.getInstance().getReference().child("notifications").child(usuarioId).push().setValue(notificationInfo);
                                                            Toast.makeText(getActivity().getApplicationContext(), usuarioNome + " entrou na sua carona", Toast.LENGTH_SHORT).show();
                                                            criarAlertaParaEnvioDeMsgAoCaroneiro(usuarioId, usuarioNome, usuarioImgUrl, usuarioTelefone);
                                                            mCheckingAuthProgress.hide();
                                                        }else{
                                                            Toast.makeText(getActivity().getApplicationContext(), "Algo deu errado. Tente novamente.", Toast.LENGTH_SHORT).show();
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    });
                                }else if("ASSENTO VAZIO".equals(nomecaroneiro4)) {
                                    novoCaroneiroMap.put("idcaroneiro4", usuarioId);
                                    novoCaroneiroMap.put("nomecaroneiro4", usuarioNome);
                                    novoCaroneiroMap.put("imgcaroneiro4", usuarioImgUrl);
                                    novoCaroneiroMap.put("vagas", numVagasTxt);
                                    caronaRef.child(ListaCaronasFragmento.idParaVerCarona).updateChildren(novoCaroneiroMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful()){

                                                HashMap<String, String> notificationInfo = new HashMap<>();
                                                notificationInfo.put("from", mAuth.getCurrentUser().getUid());
                                                notificationInfo.put("type", "pedido_aceito");
                                                usuariosRef.child(usuarioId).child("status").setValue("caroneiro_" + mAuth.getCurrentUser().getUid());
                                                //usuariosRef.child(mAuth.getCurrentUser().getUid()).child("pedidos").child(usuarioId).removeValue();
                                                notificationsOffRef.child(mAuth.getCurrentUser().getUid()).child(notificationId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if(task.isSuccessful()){
                                                            removePedidosDoCaroneiroEmOutrasCaronas(usuarioId);
                                                            FirebaseDatabase.getInstance().getReference().child("notifications").child(usuarioId).push().setValue(notificationInfo);
                                                            Toast.makeText(getActivity().getApplicationContext(), usuarioNome + " entrou na sua carona", Toast.LENGTH_SHORT).show();
                                                            criarAlertaParaEnvioDeMsgAoCaroneiro(usuarioId, usuarioNome, usuarioImgUrl, usuarioTelefone);
                                                            mCheckingAuthProgress.hide();
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    });
                                }
                            }
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void criarAlertaParaEnvioDeMsgAoCaroneiro(String idDoCaroneiro, String nomeDoCaroneiro, String imgDoCaroneiro, String telefoneDoCaroneiro){
        alert_builder2 = new AlertDialog.Builder(getActivity());
        alert_builder2.setCancelable(true);
        alert_builder2.setMessage("Envie uma mensagem para combinar detalhes da carona com " + nomeDoCaroneiro + ".");
        alert_builder2.setPositiveButton("Enviar mensagem", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mCheckingAuthProgress.setMessage("Abrindo chat...");
                mCheckingAuthProgress.show();
                Intent abrirConversa = new Intent(getActivity().getApplicationContext(), Conversa.class);
                abrirConversa.putExtra("idusuario_chat", idDoCaroneiro);
                abrirConversaTimer = new CountDownTimer(2000, 1000){
                    @Override
                    public void onTick(long millisUntilFinished) {

                    }

                    @Override
                    public void onFinish() {
                        mCheckingAuthProgress.hide();
                        abrirConversa.putExtra("nomeusuario_chat", nomeDoCaroneiro);
                        abrirConversa.putExtra("imgusuario_chat", imgDoCaroneiro);
                        abrirConversa.putExtra("telefoneusuario_chat", telefoneDoCaroneiro);
                        //abrirConversa.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(abrirConversa);
                    }
                };
                abrirConversaTimer.start();
            }
        });
        alert_builder2.setNegativeButton("Agora não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alert2.hide();
            }
        });
        alert2 = alert_builder2.create();
        alert2.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();

        if(id == R.id.action_settings) {
            Intent toPerfilIntent = new Intent(getActivity().getApplicationContext(), Perfil.class);
            Bundle extras = new Bundle();
            extras.putString("idusuario_chat", mAuth.getCurrentUser().getUid());
            extras.putString("idUsuarioCorrente", mAuth.getCurrentUser().getUid());
            toPerfilIntent.putExtras(extras);
            startActivity(toPerfilIntent);
        }else if(id == R.id.action_about){
            startActivity(new Intent(getActivity().getApplicationContext(), Sobre.class));
        }else if(id == R.id.action_privacy){
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://dragoonssoft.wixsite.com/caronacap/politica-de-privacidade"));
            startActivity(browserIntent);
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        setRetainInstance(true);

    }

    @Override
    public void onStop() {
        super.onStop();
        if(alert != null){
            alert.dismiss();
        }
        if(alert2 != null){
            alert2.dismiss();
        }
    }

    private void removePedidosDoCaroneiroEmOutrasCaronas(String caroneiroId){
        notificationsOffRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot ds: dataSnapshot.getChildren()){
                    if(ds.hasChild("from")){
                        if(ds.child("from").getValue().toString().equals(caroneiroId)){
                            notificationsOffRef.child(ds.getKey()).removeValue();
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
