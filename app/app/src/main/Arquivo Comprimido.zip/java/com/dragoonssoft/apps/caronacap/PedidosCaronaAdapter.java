package com.dragoonssoft.apps.caronacap;

/**
 * Created by wiler on 16/06/2017.
 */

public class PedidosCaronaAdapter {
}
